---
name: beta-slides
description: >-
  Create and edit Beta Mobility presentations: single-file .bento.html decks
  whose document is plain JSON in a "#bento-doc" script block, built on the
  Beta fork of bento/slides. Use whenever the user wants a slide deck or
  presentation, or mentions Slides, bento, slides.betamobility.ai, a deck
  link, a live scene, a widget or the Scenes gallery: starting from nothing
  (Beta build or template from slides.betamobility.ai), from source material,
  or by improving an existing deck. Applies the Beta design system through
  the deck's own theme, layouts and palette slots, dates refreshed data, and
  exports editable PowerPoint. Covers native slides, code slides, live HTML
  scenes (runtime slides) spliced into decks in the store, porting a
  reveal.js deck, and the scene library: insert a reviewed widget, change its
  settings, or add a new one. Full schema + recipes at
  https://slides.betamobility.ai/agents.md.
---

# Authoring Beta decks

This skill EXTENDS upstream's `bento-slides` skill; it does not replace its
guidance. **Fetch https://slides.betamobility.ai/agents.md before authoring
and follow it in full.** It is upstream's agent guide plus a "Beta build"
section, and everything below assumes you have it open: the document shape,
the material-to-feature mapping (charts, morph, state slides, ken-burns,
motion paths), the self-audit, and the gotchas all live there.

A deck is one self-contained `.bento.html` file. You edit the JSON inside
the `#bento-doc` block only, escaping every `<` as `\u003c`, and never touch
the compressed runtime around it.

## Before reading any deck: the collab check

If `doc.collab` carries `ownerPriv`, `writerPriv` or `invite`, the deck's live
session keys are in the file, and anything that receives the file or its JSON
can join that session and write to it. **Tell the user before you continue**;
only they can decide. The remedies are upstream's: a read-only copy, *Share →
Stop sharing* on a duplicate, or *Share → Rotate keys* if it already went
somewhere. This rule is inherited unchanged.

## Pick the kind of slide first

Every slide in a Beta deck is one of three kinds. Decide per slide, before
you write anything, because each is authored, stored and updated differently.

| The slide needs | Kind | People can edit it in bento | You write |
|---|---|---|---|
| Text, charts, tables, images, diagrams, morphs, animated SVG | **Native slide** | Everything: move, resize, retype, restyle | Elements in `slide.elements` |
| Source code shown to an audience, or a code walkthrough | **Code slide** (a native slide with a `code` element) | Everything, the code included | A `code` element; one slide per step for a walkthrough |
| A live page: a map to pan, a running demo, script-driven animation, a scene with its own step logic, or a slide from a hand-rolled reveal.js deck | **Live scene** (runtime slide) | Reorder, notes and the scene's declared properties; not the scene itself | A scene folder, spliced in with `splice.mjs` |

Default to native. A code slide is a native slide, so everything under
Native slides applies to it too. Reach for a live scene only when the browser
itself is the point; the test is under Runtime slides below.

Whichever kind, where the deck lives decides how you write it:

- **A file on disk** (not in the store): edit the `#bento-doc` JSON directly.
  Add, remove and reorder slides and elements freely.
- **A new deck for the store**: build it as a project folder, then create it
  with `splice.mjs --create` (with or without live scenes).
  Both need a way in to the store, and the way in is one click from the user
  in a browser they are already signed into, which the tool asks for by
  itself. See "Publishing: one click in a browser" below; never ask for a
  token.
- **A deck already in the store**: only `splice.mjs`, under the ownership
  rule. You change content by element id, replace or add live scenes, and add
  whole native slides (`{ slide, insertAfter }` in `edits.json`); you never
  move, reorder or remove slides, and never add elements to an existing one.

## Starting from nothing

Prefer a Beta template; fall back to the bare Beta shell. Never download from
bento.page: that shell has upstream's identity and self-updates from upstream.

```bash
# the general template: choose a layout within this deck
curl -fsSL https://slides.betamobility.ai/templates/general.bento.html   -o "<Topic>.bento.html"

# or the bare Beta build, then apply the theme fragment from agents.md "Beta build"
curl -fsSL https://slides.betamobility.ai/releases/slides/Bento_Slides.bento.html -o "<Topic>.bento.html"
```

A template is `template: true` with no `docId` and no `collab`. Keep it that
way in the file you write: the app mints a fresh identity on first open. When
editing an existing deck, never regenerate `docId`.

## Beta rules (on top of upstream's)

1. **No hex colours in content.** Every colour on an element is a palette
   slot recorded in `themeRefs` (`{ "color": "tx1" }`, `{ "fill": "accent1" }`,
   `{ "fill": "accent1 -20%" }`), with the literal filled from `doc.theme`.
   Slots: `bg1 tx1 bg2 tx2 accent1..accent6 hlink folHlink`. A brief that asks
   for a colour outside the system gets the nearest slot and one sentence on
   why: the design system is the deck's identity, and a deck that breaks it
   is not a Beta deck. Do not restate this on every slide.
2. **Use the general template's typefaces.** Geist for working headings and
   body text; local Times New Roman/Times for expressive openings and statements.
   Keep the full font stack from the template. Geist is embedded in HTML;
   PowerPoint recipients need it installed. Do not redistribute licensed Rhymes.
3. **Use the general layouts and preserve `role`.** Read `doc.layouts` and
   choose the composition that fits the content: `title`, `chapter`,
   `two-columns`, `chart`, `statement`, `contact`, or the other named layouts.
   Instantiate from its elements and retain their semantic roles. The canvas
   is 1280 × 720, with 64px content margins. No eyebrow headings or labels:
   place useful metadata beneath the heading, introduction or figure.
4. **Write `meta.author`** (the person presenting) and keep `meta.company`.
   Title slides and footers use `{{company}}`, `{{author}}`, `{{date}}` and
   `{{page:2}}` tokens, never literal strings.
5. **Refresh data at edit time, stamp it.** For any figure fetched from a
   Beta source (Mission Control, a report, an API), write the VALUE into the
   document and add a `source`-role text element below the figure reading
   `Data as of YYYY-MM-DD` (the date you fetched it, ISO). A deck opened on
   stage never fetches anything; the number and its date travel in the file.
6. **Live content goes in an `embed` element** only when the brief needs a
   live surface, and always with a static `view` (SVG) so it renders offline
   and prints. The guide's "Beta build" section has the shape.
7. **The default transition is `"none"`.** Every slide you write carries
   `"transition": "none"` unless the movement is the point. The Beta layouts
   share element ids, so a `morph` set by habit animates every slide change.
   Set `"morph"` only on a slide where shared elements should visibly travel
   (a before/after, a process step, a code walkthrough), and say that you did.
   The guide's advice to morph consecutive slides applies inside that limit.

## Native slides

A native slide is ordinary bento elements (`text`, `shape`, `image`,
`chart`, `table`, `svg`, `media`, `code`) placed on the slide. It is the
only kind a person can fully edit in the bento UI, so it is the default.

1. **Instantiate from a Beta layout.** Copy the layout from `doc.layouts`
   (keep its element ids, so the chrome morphs between slides), give the
   slide a new id, and fill `html` on the placeholder elements. Delete a
   placeholder you do not use rather than leaving it empty.
2. **Add elements on the grid.** 64px margins, content between x = 64 and
   x = 1216. Preserve the chosen layout’s column widths and gap. Measure text with
   `window.bento.measure()` before you size a box (agents.md).
3. **Every element carries its palette slots and role.** A text element in
   the Beta system looks like this:

   ```json
   { "id": "kpi-share", "type": "text", "x": 64, "y": 208, "w": 528, "h": 120,
     "rotation": 0, "opacity": 1, "html": "38 %", "fontSize": 96,
     "fontFamily": "'Geist', Arial, sans-serif", "fontWeight": 500,
     "color": "#242f30", "align": "left", "valign": "top", "lineHeight": 1.1,
     "role": "title", "themeRefs": { "color": "accent1" } }
   ```

4. **Ids are yours to choose and keep.** Use readable, deterministic ids
   (`kpi-share`, `map-legend`), unique within the slide. They are how
   `edits.json` finds an element later, how morphs pair and how comments
   anchor. An element that should travel between two slides keeps the same
   id on both, and the second slide sets `"transition": "morph"`.
5. **Animated diagrams stay native.** An `svg` element with `@keyframes` in
   its `<style>` animates in present mode and stays movable in the editor
   (agents.md, "Motion without a runtime slide").

In a stored deck, a person may since have moved, resized or restyled what you
wrote. Read the deck first, take ids from that copy, and change only content
through `edits.json` (the key per type is listed under Runtime slides). If the
brief needs a native slide that is not in a stored deck yet, add it whole
with an `edits.json` entry `{ "slide": { "id": "…", "elements": […], … },
"insertAfter": "<slide id>" | "end" }`: instantiate it from a Beta layout as
for a new deck, give it an id the deck does not have, and put images in as
data: URIs (the tool moves them into the deck's assets). It lands as an
ordinary slide people can edit; every slide already there stays as it was.
This is also how slides from another deck are merged into a deck in use,
keeping its link. Never rebuild the deck to get round the ownership rule.

## Code slides

Code goes in a `code` element, never in a text element or a screenshot. It
keeps the source as plain text, highlights it, stays editable in the editor
(double-click it), and between two slides it **morphs token by token**: lines
that moved travel to their new place and new tokens fade in.

```json
{ "id": "code-main", "type": "code", "x": 96, "y": 176, "w": 1088, "h": 440,
  "rotation": 0, "opacity": 1,
  "content": "export function fare(km: number) {\n  return 32 + km * 4.5\n}",
  "grammarName": "ts",
  "fontSize": 28, "fontFamily": "'DM Mono', 'Courier New', monospace",
  "color": "#1A1A1A", "align": "left", "valign": "top", "lineHeight": 1.45,
  "role": "body", "themeRefs": { "color": "tx1" } }
```

- **`content`** is the raw source: real newlines (`\n` in JSON), spaces for
  indentation, no HTML and no escaping beyond JSON's own. Every `<` becomes
  `\u003c` when the block is written back, as for any string in the document.
- **`grammarName`** picks the highlighter: `ts`, `js`, `py`, `sql`, `sh`,
  `json`, `yaml`, `go`, `rust`, `java`, `csharp`, `kotlin`, `swift`, `html`,
  `css`, `dockerfile`, `hcl`, `r`, `diff`, `md` and about sixty more (the
  editor's Language menu lists them all). Names are these exact ids: shell is
  `sh`, not `bash`, and an unknown name silently falls back to `js`. Use `diff` to show a change with added
  and removed lines coloured.
- **Colours.** The syntax colours are fixed by the renderer and are not
  palette slots. Only `color`, the colour of plain tokens, is yours: `tx1` on
  a light slide, `bg1` on a dark one. For a panel behind the code, put a
  `shape` rect with `fill` on `bg2` (and its `themeRefs`) under the element.
- **Type.** DM Mono at 24 to 32 px, `lineHeight` about 1.45. Lines do not
  wrap and anything past the box is clipped. At 28 px a 1088 px box holds
  about 60 characters per line, and a box holds `h / (fontSize × lineHeight)`
  lines: about 10 in the 440 px box above. Cut the code to fit rather than
  shrinking the type below 22 px.
- **A walkthrough is a sequence of slides.** Duplicate the slide, change
  `content`, keep the element's `id` the same (or give each copy the same
  `morphId`), and set `"transition": "morph"` on every slide after the first.
  Change a little per step: one function added, one line moved. Put the
  explanation in a title or a side column, not in code comments.
- **In a stored deck** the splice tool cannot change a code element: its
  `content` is not one of the keys `edits.json` accepts, and the tool refuses
  it. Author code slides before the deck goes into the store (in the file, or
  in `deck.json` for `--create`). Once it is stored, the person changes the
  code in the editor (double-click the block), and a new walkthrough step is
  a slide they duplicate there.
- **PowerPoint** gets the code as monospace text without syntax colours; the
  export report names each one (`code-colour`). Say so with the report.
- Code that has to **run** in front of the audience is a live scene, not a
  code element.

## Workflow

1. Run the collab check above.
2. Fetch the agent guide; classify the source material; map it to features
   (chart, table, morph, state slide, hero, sequence, headline number,
   media), exactly as upstream's workflow says.
3. Author from a Beta template or the bare shell, under the Beta rules.
4. `window.bento.validate()` clean, then **open the deck and look at every
   slide** (upstream's rule; a deck nobody rendered is not finished).
5. **Export PPTX** and read the report to the user: every element that
   became a picture or lost a gradient is named there. Say it before they
   send the file. In a browser it is the button beside Export PDF; from a
   file harness (no browser) run the same mapper headlessly:

   ```bash
   node scripts/export-pptx.mjs "<Topic>.bento.html"    # from a checkout of betamobility/slides
   ```

   It writes `<Topic>.pptx` beside the deck and prints the report.
6. Write back the `#bento-doc` block, or return the replacement JSON.
7. **Offer to publish it**, if the user wants a link rather than a file. The
   deck store lives on the same host as everything else above, behind Beta's
   login, and publishing needs no secret: the tool asks the user for one
   click in a browser (see "Publishing: one click in a browser" below).

   ```bash
   # the slides in <projectDir>/deck.json → prints https://slides.betamobility.ai/d/<id>
   node splice.mjs --create <projectDir>
   ```

   A deck that exists only as a finished file is saved by the user instead:
   they open it and pick **Share → Save to the cloud**. **A deck that is already
   in the store is changed only with `splice.mjs`.** There is no hand-written
   replace: the tool reads the deck, keeps what people arranged, and writes
   back only if nobody saved in between.

   Give the user the link the tool prints. Anyone signed in at
   `https://slides.betamobility.ai/` sees the deck in the list and can edit
   it; the link is the invitation.

## Runtime slides

A runtime slide is one live HTML scene that fills a whole slide. In present
mode the scene runs in a sandboxed frame; everywhere else (editor,
thumbnails, print, PDF, PowerPoint, an older shell) the slide is its still,
a picture you draw. The guide's "Beta build → Runtime slides" section has the
record shape and the full protocol.

### Use one only when the browser is the point

**Try an `svg` element with `@keyframes` first.** Its `<style>` animations
run in present mode and restart every time the slide is entered, the slide
stays editable in the UI, and most animated diagrams need nothing more (see
"Motion without a runtime slide" in the guide). Text, charts, tables, step
reveals and morphs are native features; never make a runtime slide for them.

Use a runtime slide for what the file's own elements cannot do: a map people
pan and zoom, a live demo, bespoke animation driven by script, anything where
the browser runtime is the thing being shown.

### The project folder

Scenes are files you write and preview in a browser, then splice into the
deck. One folder per deck:

```
<project>/
  deck.json                      --create only: { "title": "…", "slides": [ … ] }
  edits.json                     optional: content changes to native elements
  assets/<name>                  heavy files shared by several scenes
  scenes/<slideId>/index.html    the scene
  scenes/<slideId>/still.svg     or still.png, exactly one
  scenes/<slideId>/scene.json    { "steps": 3, "props": [ … ], "assets": [ … ], "url": "https://…", "insertAfter": "s2" }
  scenes/<slideId>/assets/<name> heavy files this scene lists
```

The folder name under `scenes/` is the slide id. In `scene.json` every key is
optional: `steps` (a whole number, default 0), `props` (a list of
`{ "key", "label", "kind": "text" | "number" | "color", "default" }`),
`assets` (file names, looked up in the scene's `assets/` and then the
project's `assets/`) and `url` (https only: the frame loads that page instead
of `index.html`, which must still exist) and `insertAfter` (update only: add
this scene as a new slide, see below). Keys pressed inside a hosted `url`
page do not drive the show; the presenter clicks outside the frame to get the
arrows back, and offline the still shows.

Assets are stored per deck, not per scene: two scenes may list the same asset
name only when the files hold the same bytes. The same name with different
bytes stops the run before any request, so give one of the files another
name.

### A scene

The scene waits for `bento:init` before it trusts any state, installs its
message listener before it sends `bento:ready`, and leaves slide navigation
to the shell. Start from this:

```html
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
  html, body { margin: 0; height: 100%; overflow: hidden; background: #F5F3EF; color: #1A1A1A; font: 28px/1.4 Inter, system-ui, sans-serif; }
  main { padding: 96px; }
  .step { opacity: 0.15; transition: opacity 0.4s; }
  .step.on { opacity: 1; }
  .reduce .step { transition: none; }
</style>
</head>
<body>
<main>
  <h1 id="title"></h1>
  <p class="step">First point</p>
  <p class="step">Second point</p>
  <p class="step">Third point</p>
</main>
<script>
  // Defaults match scene.json, so the file previews on its own in a browser.
  const state = { step: 0, props: { title: 'Title' }, assets: {} }

  function render() {
    document.getElementById('title').textContent = state.props.title
    document.querySelectorAll('.step').forEach((el, i) => el.classList.toggle('on', i <= state.step))
    // state.assets[name] is an object URL, or missing: always draw something without it.
  }

  window.addEventListener('message', (ev) => {
    if (ev.source !== window.parent) return // never test ev.origin: a sandboxed frame's is 'null'
    const m = ev.data || {}
    if (m.type === 'bento:init') {
      state.step = m.step // the last step when the presenter arrives going backwards
      Object.assign(state.props, m.props)
      document.body.classList.toggle('reduce', m.reduceMotion)
    } else if (m.type === 'bento:step') {
      state.step = m.index
    } else if (m.type === 'bento:props') {
      Object.assign(state.props, m.values)
    } else if (m.type === 'bento:motion') {
      document.body.classList.toggle('reduce', m.reduce)
    } else if (m.type === 'bento:assets') {
      for (const [name, blob] of Object.entries(m.assets)) state.assets[name] = URL.createObjectURL(blob)
    } else {
      return
    }
    render()
  })

  // Keys pressed inside the frame never reach the shell. Forward the ones the
  // scene does not use; the shell steps or changes slide and takes focus back.
  const NAV = { ArrowRight: 'next', ' ': 'next', PageDown: 'next', ArrowLeft: 'prev', PageUp: 'prev', Escape: 'exit' }
  window.addEventListener('keydown', (ev) => {
    const dir = NAV[ev.key]
    if (!dir || ev.defaultPrevented || ev.target.closest?.('input, textarea, select')) return
    ev.preventDefault()
    window.parent.postMessage({ type: 'bento:navigate', dir }, '*')
  })

  render()
  window.parent.postMessage({ type: 'bento:ready' }, '*')
</script>
</body>
</html>
```

Rules the template already follows:

- **Steps belong to the shell.** It counts them from `scene.json`, walks
  them with the arrows before leaving the slide, and tells the scene with
  `bento:step { index }` (from 0). A scene that also moves a step on its own
  arrow handling double-steps. Steps only count once the scene has sent
  `bento:ready`; before that, and in a frame that failed to load, the arrows
  change slide.
- **Nothing reaches a scene before `bento:ready`.** `bento:init { step,
  steps, props, reduceMotion }` comes first, then `bento:assets`.
- **Honour reduced motion** (`reduceMotion` in init, `bento:motion {
  reduce }` later).
- **A scene is self-contained.** Its CSS, script and small data are inline;
  it makes no request for its assets itself.

### Porting a reveal.js deck: one section, one live scene

A hand-rolled reveal.js deck (maps fetched at runtime, fragment-driven
animations, a live iframe) becomes a beta/slides deck without rewriting its
code. Each top-level `<section>` becomes one runtime slide that runs the
section's own markup, the deck's own CSS and the deck's own script. Reveal
itself is never loaded: `reveal/shim.js` in this skill's folder stands in for
it. The shell sends `bento:init` and `bento:step`, and the shim turns them
into the `ready`, `slidechanged`, `fragmentshown` and `fragmenthidden` events
the deck script already listens to. This is how the Danmarks Mobilitetsatlas
deck was ported on 2026-09-14: 15 sections, 22 fragment steps, runtime-fetched
maps and a live iframe.

1. **Read the deck and plan each section.** Give it a slide id and a kind:
   - a plain statement (a heading or a sentence, no script) becomes a
     **native slide** in `deck.json`, a text element under the Beta rules, so
     people can edit it in the app;
   - a section with `data-background-iframe="https://…"` becomes a **url
     scene**: `scene.json` sets `url` to that page, and `index.html` is a
     one-line placeholder;
   - everything else becomes a **scene**.

   One flat `<section>` per slide: split a vertical stack (a section inside
   a section) into separate sections first.
2. **Write `scenes/<id>/index.html` for each scene**, in this order:

   ```html
   <!doctype html>
   <html lang="da"><head><meta charset="utf-8">
   <style>
   /* reveal/reset.css, then reveal/reveal.css (this skill's folder, or the deck's own copies) */
   /* the deck's own stylesheets and <style> blocks, in the order the deck links them */
   html,body{margin:0;width:100%;height:100%;overflow:hidden}
   .reveal .slides > section{display:block}
   </style></head>
   <body class="reveal-viewport"><div class="reveal"><div class="slides">
     <section class="present …the section's own classes…" id="…"> …the section's markup… </section>
   </div></div>
   <!-- Reveal.initialize's width and height; Reveal's default is 960x700 -->
   <script>window.BENTO_REVEAL_SIZE = { width: 1280, height: 720 }</script>
   <script>/* reveal/shim.js, verbatim */</script>
   <script>/* the deck's own script(s), verbatim, without reveal.js and its plugins */</script>
   <script>parent.postMessage({ type: 'bento:ready' }, '*')</script>
   </body></html>
   ```

   Drop `data-transition`, `data-auto-animate` and `data-background-*` from
   the section tag. Write every `</script>` inside inlined code as
   `<\/script>`. The deck script is shared by every section, so it must
   cope with only one section being present; the atlas script did, because
   it looks slides up by id.
3. **`scene.json`**: `steps` is the number of fragment groups plus one (step
   0 shows none), or 0 for a section without fragments. Fragments that share
   a `data-fragment-index` are one group; each fragment without one is its
   own group, after the indexed ones, which is Reveal's order. `assets` lists
   every file the scene fetches as `assets/<name>`, copied into
   `scenes/<id>/assets/`. The shim answers `fetch('assets/<name>')` from the
   files the shell delivers, so the deck's fetch code runs unchanged. The
   shared script usually fetches files for several slides, so list per scene
   only the ones that scene draws.
4. **Stills**: screenshot the original deck at each slide's last step and
   shrink it (`sips -Z 960 in.png --out still.png`, smaller again until it is
   under budget; slide one under about 45 KB). A still is `still.png` or
   `still.svg`, nothing else.
5. **Check each scene before splicing.** Copy `reveal/harness.html` into the
   project folder, serve the folder (`python3 -m http.server 8797`), and open
   `http://127.0.0.1:8797/harness.html?scene=<id>`. It frames the scene the
   way present mode does, delivers its assets, and steps it with the arrow
   keys (or `step(3)` in the console). Walk to the last step and back to 0,
   and check the console is clean.
6. **Splice**: `splice.mjs --create <projectDir> --dry-run`, then without
   `--dry-run`. A later change to the source deck is ported into the same
   folders again and pushed with `splice.mjs <deckId> <projectDir>`, which
   replaces only the runtime slides and leaves the native slides as people
   left them.

Know before you port:

- **Each scene carries its own copy** of reveal.css (about 54 KB) and of the
  deck's CSS and script. The atlas scenes came to about 120 KB each and the
  deck to 3.7 MB. A scene over 256 KB is refused: move inline data and images
  out to `assets/`.
- **Stepping backwards into a slide** enters it at its last step, and the
  shim replays the fragment events up to there at once. A deck script that
  ignores a step while the previous animation is still running comes to rest
  earlier. The atlas port has this gap on two slides.
- **External fonts.** A `<link>` to Google Fonts in a scene works when the
  deck is opened online, not offline, and it breaks the rule that a scene is
  self-contained. The store's content security policy only reports that link
  today (`content-security-policy-report-only`); if it is ever enforced, the
  fonts fall back. Embed the faces as `data:` URIs in the scene CSS when that
  matters.
- **Reveal calls that navigate** (`Reveal.next()`, `Reveal.slide()`) do
  nothing in a scene, because the shell owns navigation. Other calls the shim
  does not implement log a warning rather than throw.
- A script inside a section's markup runs before the shim. If it calls
  `Reveal`, move it after the deck script.

### The still

The still is a placeholder picture of the scene. For a new scene, draw it: a
hand-drawn SVG (the outline of the map, the first frame of the demo, a title)
or a small PNG. Never trace a map into vectors or paste a screenshot of a map
as the slide's content. **When porting a deck that already renders** (a
reveal.js section, below), the still is a screenshot of that slide at its last
step, shrunk to budget. It is what thumbnails,
print, PDF, PowerPoint and older shells show, and what present mode shows
when the frame fails to load.

Keep it small. The hard cap is 200 KB. When the runtime slide is slide one,
keep the still under about 45 KB: every save writes a first-page thumbnail
into the file under a 64 KB budget, the still travels as base64 (a third
larger), and above that budget the thumbnail drops the picture for a tinted
box.

### Budgets and assets

- `index.html`: 256 KB at most, inlined into the deck.
- The still: 200 KB at most, always inlined.
- Anything heavier (a 7 MB map, a GeoJSON, a CSV) goes in `assets/` and is
  listed in `scene.json`: 16 MB per file, at most 64 per scene, types
  png, jpg, webp, svg, json and csv. Names are letters, digits, `.`, `_`
  and `-`. The tool uploads them to the store's asset route; an SVG asset has
  scripts, `foreignObject` and event handlers stripped on upload.
- **Referenced assets play only when the deck is opened from the store by a
  signed-in person.** The shell fetches them from
  `https://slides.betamobility.ai/d/<id>/assets/<name>` and hands the bytes to
  the scene. A copy on disk, in Drive or downloaded runs the scene without
  them, so the scene must still draw something. Assets belong to one deck id:
  a "Duplicate as new deck" copy has none until the tool runs against it.

The tool refuses anything over budget and writes nothing.

### Creating and updating a deck with splice.mjs

The tool is `splice.mjs`. Look for it in this order: `scripts/splice.mjs`
inside this skill's own folder (the Beta toolkit installs it there); then
`scripts/splice.mjs` next to the plugin's `skills/` folder (the standalone
beta-slides plugin); then `plugins/beta-slides/scripts/splice.mjs` in a
checkout of betamobility/slides. It needs Node 18 or newer and
nothing else, and no credential from you: the first command that reaches the
store prints an approval link for the user (next section). It reads
`SLIDES_STORE_URL` from the environment when set (default
`https://slides.betamobility.ai`).

```bash
# the approval alone, before any work (next section)
node splice.mjs --link

# a stored deck as it is now, and the ids an edit needs
node splice.mjs --read <deckId> [--out current.bento.html]

# the scene library: each scene's id, settings and presets
node splice.mjs --library

# a new deck: the published blank template, deck.json's slides, then the scenes
node splice.mjs --create <projectDir> [--dry-run] [--skip-url-check]

# an existing deck: replace or insert runtime slides, apply edits.json
node splice.mjs <deckId> <projectDir> [--edits edits.json] [--title "<title>"] [--dry-run] [--skip-url-check]

# an existing deck, content fixes only (a typo, a figure): no project folder
node splice.mjs <deckId> --edits edits.json [--title "<title>"] [--dry-run]

# an existing deck, renamed: nothing else changes
node splice.mjs <deckId> --title "<title>" [--dry-run]
```

`<deckId>` is the ten characters at the end of `/d/<id>`. Every command
prints what it did and the deck's link. Exit code 0 is success, 1 is a
refusal or a store error (the message says which; a refusal comes before the
deck write, and in update mode the deck itself was not changed), 2 is a usage
error.

Every request to the store times out: 30 seconds for reading or writing a
deck and for the blank template, 120 seconds for each asset upload. A timeout
stops the run with a message naming the request. Assets go up before the deck
is written, so if the run fails after that, the message lists the assets that
were uploaded and says the deck itself was not changed. With `--create`, the
new deck's link is printed as soon as the store creates it; if an asset
upload then fails, the error carries the deck id, and you finish with
`splice.mjs <deckId> <projectDir>` rather than creating a second deck.

- **`--create`**: `deck.json` holds full bento slides, each with an `id`. A
  slide whose id matches a scene folder is where that runtime slide goes;
  other scenes are added after the native slides. The deck gets a fresh
  `docId` and the Beta theme, fonts and layouts from the blank template.
- **Update**: a folder under `scenes/` whose name is a runtime slide in the
  deck replaces that slide. An id two slides share, or the id of a native
  slide, stops the run; the tool never turns a native slide into a runtime
  slide. A folder whose name is not in the deck stops the run too, unless its
  `scene.json` sets `insertAfter`. A runtime slide that holds elements other
  than its still (something pasted onto it, say) stops the run naming those
  element ids, because the replace would delete them; ask the person to move
  or delete them in the editor.
- **Adding a runtime slide to an existing deck**: pick a new slide id that no
  slide in the deck uses, name the folder after it, and set `"insertAfter"` in
  its `scene.json` to the id of the slide it follows, or `"end"` to append.
  The anchor must be a slide in the deck as it is now (not another new
  scene); the new slide goes after it and after any states of it, and takes
  its background. Once inserted, the next run replaces it like any other
  runtime slide and `insertAfter` is ignored.
- **Edits only**: with no scene to change, run
  `splice.mjs <deckId> --edits edits.json`. A run with neither scene folders
  nor edits nor `--title` is refused.
- **`--title "<title>"`** (update only) renames the deck: it changes the
  document title and nothing else at document level. It works alone, or
  beside scenes and edits. With `--create`, the title comes from `deck.json`.
- **The url check**: when a `scene.json` sets `url`, the tool fetches that
  page once before it touches the store (following one redirect) and stops
  if the page refuses to be framed by `https://slides.betamobility.ai`: an
  `X-Frame-Options` header (DENY or SAMEORIGIN), or a
  `Content-Security-Policy` whose `frame-ancestors` does not allow that
  origin. Such a page would show only its still in the deck. A page the tool
  cannot reach (an internal one, say) prints a warning and the run goes on.
  `--skip-url-check` skips the check; use it only when you know the page
  allows framing.
- **`edits.json`** is a list of edits. Besides content edits (below) it holds
  library inserts and settings edits (next section). Content edits change
  the content of native elements by id:
  `[{ "slideId": "s3", "elementId": "t-04", "html": "New text" }]`. The one
  key per type is `html` (text), `src` (image, media), `option` (chart),
  `rows` (table) and `url` (a web page embed). Anything else is refused.
  A `url` edit stays on the embed's site (same origin, an http or https
  address the editor keeps, at most 2048 characters); on a library web
  scene it changes only the scene's declared settings in the query string,
  as the settings panel does, and the page and fragment stay. A url edit
  is not framing-checked: the site is the one the person already chose.
- **`--dry-run`** reads the deck and prints the plan without writing. Run it
  first.
- An encrypted deck is refused; the tool does not decrypt. A deck that is
  open in someone's tab (not in a live session) while the tool writes takes
  the write in: a tab with nothing unsaved reloads onto it, and a tab with
  unsaved edits merges it into what the person is doing, on its next save or
  when it next takes focus.
  Where you and the person changed the same element, the person's version
  stays (the store keeps yours in the deck's version history), so edit what
  you were asked to and leave the rest alone. Encrypted decks and shells
  from release 2026.11.2 or earlier still lock instead of merging. A deck in
  a live session while the tool writes is still unsupported: it has not been
  tested, so ask the people in it to stop editing first.

### The scene library: insert a reviewed scene, change its settings

Beta keeps reviewed, reusable scenes in a library on the store: today a
counter, a map, a KPI row, a timeline, a before-and-after comparison and an
annotated bar chart (`counter`, `map`, `kpi-row`, `timeline`,
`before-after`, `annotated-bars`). Prefer one over writing a scene from
nothing when it fits: it is already reviewed, it has a still, and the person
can change its settings in the editor's panel without you.

```bash
node splice.mjs --library      # what there is: ids, settings (kind, format, default) and presets
```

Insert one as a new runtime slide with a `library` edit in `edits.json`:

```json
[{ "library": "map", "id": "cph", "insertAfter": "s3", "preset": "Copenhagen", "values": { "zoom": 7 } }]
```

- `id` names the new slide (no slide in the deck may use it); `insertAfter`
  is the id of a slide in the deck, or `"end"`. The slide goes after that
  slide and its states.
- `preset` is a preset's name from `--library` (the first preset when you
  leave it out); `values` go over the preset's. Every setting you do not name
  keeps the preset's value or its default.
- The slide is exactly what the editor's Scenes gallery writes: the scene's
  page inlined, its still, its settings and a library marker. Only runtime
  scenes can be inserted this way; a web scene goes on a slide the person
  owns, so tell them to insert it from the editor's **Scenes** button.

Change a library slide's settings with a `values` edit, never by replacing
it from a folder:

```json
[{ "slideId": "cph", "values": { "place": "Malmö", "position": "55.605, 13.0038" } }]
```

- Only the settings you name change; every other value, including what the
  person set in the panel, stays. `--read` lists library slides with their
  current values.
- A value must be one the setting keeps as given, or the run is refused,
  naming the key: the right kind, one of a `select:` list's choices, `0` or
  `1` for `bool`, inside a `range:min:max:step` and on its steps, and a
  position written `"latitude, longitude"` with a comma and a space and at
  most six decimals.
- A slide carrying a library marker is replaced from a scene folder only
  when that folder's `scene.json` declares the same `"library": "<id>"`.
  Without it the run is refused, naming the slide: the replace would discard
  what the person set. Declared, the replace is a normal replace (values are
  dropped, as for any replace) and the marker stays.

### Adding a scene to the library

Write a library scene when the same live scene will be wanted in more than
one deck: a widget people insert from the editor's **Scenes** gallery and
tune in its settings panel. A scene for one deck stays a scene folder in
that deck's project. Check `node splice.mjs --library` first; a setting on
an existing scene is cheaper than a new one.

A library scene is a folder in the betamobility/slides repository, reviewed
like code on its own branch and pull request:

```
beta/library/<id>/
  scene.json    name, version, description, kind, steps, props, presets
  index.html    the page (kind "runtime"), the same scene contract as any runtime slide
  still.svg     what the slide shows wherever no frame runs
```

- `<id>` is lower case letters, digits and hyphens, starting with a letter.
  Copy `beta/library/counter/` (no steps) or `beta/library/map/` (two steps)
  as the starting point, or `beta/library/kpi-row/` for a scene whose still
  is captured: one that draws into `<svg id="scene">` by arithmetic (no
  measured text) has its `still.svg` written by
  `node scripts/build-beta-library-stills.mjs <id>`, and the browser rig
  fails when that still is stale. Its colours and fonts come from one
  `TOKENS` table of `beta/v131/tokens.json` values, which
  `scripts/test-beta-library.ts` checks.
- `version` is a whole number. Raise it on every change: a deck keeps the
  copy it was given, and the number says which.
- `index.html` follows "A scene" above: wait for `bento:init`, send
  `bento:ready`, leave steps and navigation to the shell, honour reduced
  motion, and draw its defaults on its own so it previews in a plain
  browser tab. Everything inline; at most 256 KB as the shell measures it
  (base64, padding included).
- `still.svg` is a picture: no script, no `foreignObject`, no event
  handlers, no links out, and under about 60 KB so it travels with the
  slide to every collaborator.
- `props` are the settings the person edits in the panel, with the shell's
  three kinds: `text`, `number`, `color`. Anything else rides on `text` or
  `number` with a `format` hint: `bool`, `latlon`, `select:a|b|c`,
  `range:min:max:step`. Every prop has a `default`, and the scene reads
  every value from `bento:init` and `bento:props`.
- `presets` name sets of values; there is at least one, the gallery opens on
  the first, and a preset lists only what differs from the defaults.
- A web scene (`"kind": "web"`) has a `url` instead of `index.html`; it is
  `https` on a host Beta controls (`WEB_HOSTS` in
  `slides/src/beta/libraryrules.ts`: today `slides.betamobility.ai` and
  `design.betamobility.ai`).

Check it before the pull request, with the same commands CI runs:

```bash
node scripts/build-beta-library.mjs --check     # validates every folder into one manifest
node scripts/test-beta-library.ts
node scripts/test-beta-library-browser.mjs      # needs Chrome and a built shell
```

Open `index.html` in a plain browser tab to see the defaults before calling
it done. Merging does not reach
the gallery: `node scripts/build-beta-library.mjs --upload` publishes the
manifest to the store with the store's service token, and that is a release
step the maintainer runs or asks for, never one an agent takes on its own.
Once uploaded, the scene is in every signed-in person's **Scenes** gallery,
in `node splice.mjs --library`, and insertable with a `library` edit.

### Publishing: one click in a browser

**Nobody handles a secret to publish.** The first `splice.mjs` command that
reaches the store with no approval on this machine starts a pairing by
itself: it prints one instruction and one URL ending in `/link/<code>`, waits
for the user to approve, and then carries on with what you asked for.

```bash
SLIDES_GRANT_LABEL="Claude Code" node splice.mjs --create <projectDir>
```

1. Run the command you need **in the background**, or with the longest
   command timeout your shell allows: it prints the link at once and then
   waits up to ten minutes for the click, and a shell that shows output only
   when a command returns would hide the link until it is too late. Read the
   link from the command's output while it runs.
2. Give the user that URL, as a link, and wait. Do not run anything else
   meanwhile. **Never open or approve the link yourself**, with a browser
   tool or any other way: the click is the user's consent and nobody else's.
3. They open it in a browser where they are already signed in, see what is
   being granted ("publish decks as you", for 30 days, when the pairing
   started, and what you called yourself), and click **Approve** once.
4. The command continues, saying who approved and until when. Every later
   `splice.mjs` command publishes as them, with no second approval.
5. When it exits, read its last lines. Exit 0 ends with the deck's link:
   give it to the user. Any other exit is a refusal that says what to run
   next: report it, do not guess.

**A command your shell kills while it waits takes the pairing with it**: a
click made afterwards approves nothing you can use, and the next run prints a
new link. That is why the pairing runs in the background. If it happened
anyway, tell the user the first link is dead and ask for one click on the new
one. `node splice.mjs --link` does the pairing alone, for when you want the
approval in place before the work starts.

`--create --dry-run` needs no approval. A dry run of a change to a stored
deck does, because it reads the deck.

**Say who you are.** `SLIDES_GRANT_LABEL` is the name the approval page shows
and the name on the user's Agent access list. In Claude Code set
`SLIDES_GRANT_LABEL="Claude Code"` on the command that pairs, as above; left
unset, the label is "Claude (Cowork)".

The approval lasts **30 days**, so a month of work and any number of decks ask
once. It can create decks, and read and change any deck by its link; it
cannot list the store, delete a deck, or read a deck's live-session keys. The
user can end it at any time from the deck list at `slides.betamobility.ai`,
under **Agent access**.

The approval is kept in `~/.bento/slides-grant.json`, readable only by the
user, and never beside the deck. **Cowork may not keep `~/.bento` between
sessions**, so there a new session can mean one new click; that is expected,
not a fault. A shell whose home directory is missing or cannot be written is
refused before anyone is asked to click; set `SLIDES_GRANT_FILE` to a file
outside the deck folder and run again.

**Never ask the user for a token, a secret or anything to paste.** If a
command refuses and says `CI` is set, the shell is marked as a machine run
(the variable counts when set to anything, even empty). With a user present,
run `node splice.mjs --link` there, in the background as above; it pairs
regardless. Then repeat the command. In a real unattended job, stop and say so; do not pair.

**When an approval lapses**, the next command asks for one more click the
same way. If the store ends it mid-run (the user revoked it), the tool says
so and names `--link`. Do not fall back to a hand-written `curl` replace.

**When nobody clicks**, the pairing expires after ten minutes and the tool
says nothing was published. Nothing in the store changed and the project
folder is untouched. Say that, rather than reporting the work as lost, and
run the same command again when the user is at a browser.

**When the sandbox cannot run `node` or reach the store at all**, a new deck
can still be handed over as a file (below). A deck already in the store
cannot be changed from there: the user edits it in the editor, or you change
it from a shell that has `node`.

> Open the file (download it and double-click, or drag it into Chrome), then
> **Share → Save to the cloud**. A store tab opens, you sign in, and you get back a
> `slides.betamobility.ai/d/<id>` link. From then on ⌘S in that tab saves back
> in place.

Save to the cloud appears in the Share panel whenever the deck is open off the
store origin, and it needs a valid `@betamobility.io` identity. Anyone else
gets the login page and keeps the file, which is a complete deck with the
editor and Export PPTX already in it. Say that plainly rather than reporting
the deck as unfinished.

### Machines and CI: the service token

This section is for unattended runs only: a CI job, a scheduled pipeline. A
person never needs it, and you never ask a person for what it uses.

A machine run sets `CF_ACCESS_CLIENT_ID` and `CF_ACCESS_CLIENT_SECRET` from
its own secret store, never from a file in the repo. When both are set the
tool uses them, through `/api/harness/`, and ignores any saved approval. A
run with `CI` set (to anything, even empty) and no token refuses instead of
pairing, because nobody is there to click.

The token may create a deck, read a deck whose id it already has, and replace
it; it cannot list decks, so a leaked token cannot enumerate anyone's work. A
read with it hands over the whole file, including the deck's live-session
owner keys, so treat a deck downloaded this way like the token itself.

For a machine with the token and no `node`, the two routes the tool uses:

```bash
# create a deck with no runtime slides → 201 {"id":"<id>","url":"https://slides.betamobility.ai/d/<id>"}
curl -fsS -H "CF-Access-Client-Id: $CF_ACCESS_CLIENT_ID" \
          -H "CF-Access-Client-Secret: $CF_ACCESS_CLIENT_SECRET" \
          -H 'content-type: text/html; charset=utf-8' \
          --data-binary "@<Topic>.bento.html" \
          https://slides.betamobility.ai/api/harness/decks

# read a deck as it is now
curl -fsS -o current.bento.html \
     -H "CF-Access-Client-Id: $CF_ACCESS_CLIENT_ID" \
     -H "CF-Access-Client-Secret: $CF_ACCESS_CLIENT_SECRET" \
     https://slides.betamobility.ai/api/harness/decks/<id>
```

### The ownership rule (hard rule)

**Claude owns content, the UI owns geometry.** You replace runtime slides
wholesale and change the text, images, chart data and table cells of native
elements by id. You never change an element's position, size or rotation,
never add, remove or reorder slides or elements (the one exception is a new
runtime slide placed with `insertAfter`), and never touch slide notes,
backgrounds or transitions in a stored deck. People move things in the
editor, and their layout always survives your update. The tool enforces this:
it compares what it would write with what it read and refuses any change
outside the rule.

A replace resets the values a presenter set for a scene's properties to your
defaults. The tool's plan output (with `--dry-run` and on a real run) has a
line `<slideId>: presenter values dropped by the replace: key="value", …` for
each replaced slide that had them. Pass that line on to the user.

**Never regenerate a deck from a script once people have edited it.** A
fresh `--create` is a new deck; it does not update the old one.

**Read before you write.** Before you plan a change, read the deck as it is
now, not a copy from earlier in the session:

```bash
node splice.mjs --read <deckId> [--out current.bento.html]
```

It writes the deck to a file and prints the inventory an `edits.json` is built
from: every slide, which ones are runtime slides you replace wholesale, and
every native element with the one key an edit may change. It goes through the
same approval as every other command and never puts a credential in a command.

Take slide and element ids from that file, then change it with `splice.mjs`.

### When the tool reports a 412

A 412 means someone saved the deck after the tool read it. The tool reads
again and redoes its changes against the fresh copy, up to three times. If
every attempt loses, it stops with "the owner probably has the deck open":
autosave changes the deck every few seconds while someone edits. Nothing was
written. Tell the user, ask the person to close the deck or stop editing, and
run the command again. Never work around it.

## Self-audit (Beta additions to upstream's list)

- [ ] Every colour is a palette slot via `themeRefs`; no hex in content?
- [ ] Three faces only, full stacks, all embedded (`validate()` shows no
      `font-not-embedded`)?
- [ ] Every text element carries a `role`; slides come from Beta layouts?
- [ ] `meta.author` set; tokens, not literals, in title slides and footers?
- [ ] Every fetched figure has a `Data as of` source note below it, with no eyebrow?
- [ ] Each slide is the right kind: native by default, source code in a
      `code` element with a real `grammarName`, a live scene only where the
      browser is the point?
- [ ] A reveal.js port: one flat section per scene, `steps` = fragment
      groups + 1, every fetched file listed in `assets`, each scene walked
      forward and back in the harness?
- [ ] A code walkthrough keeps one element id across its steps, with
      `morph` on every step after the first, and no line clipped at the box?
- [ ] PPTX exported and its degrade report reported to the user?

For new decks use the general template (design system v1.5.0): 35 editable layouts, embedded Geist, no eyebrows, white/sage/peach/deep surfaces and the standard bottom-left logo. Since release 2026.10.11 the blank, client-pitch, insight-brief and workshop templates are built on the same layouts and theme.
